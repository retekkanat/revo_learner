#!/usr/bin/env python3
# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Check that a laptop is ready for the AWS Forward Deployed Engineer programme.

Learners run this script once they have followed laptop-setup.md:

    uv run check_laptop.py

The script checks the Python version, the command-line tools that the course
uses, the AWS Region setting, whether the AWS CLI profile uses a long-term
access key, and the AWS CLI sign-in. It prints one PASS, WARN or FAIL line for
each check and a summary line. A WARN line marks a setting that the course
allows but does not prefer. The script exits with status 0 when no check
fails and 1 otherwise. Until the learner's AWS access is ready, which can be
as late as the start of Week 2, only the sign-in check fails, and the summary
line says that this is the expected result.

The script changes nothing on the laptop or in the AWS account. It never
prints an AWS account identifier, an access key, a secret or an ARN, so its
output is safe to show to the instructor.

It uses only the Python standard library and runs on macOS, Linux and Windows. It
avoids syntax newer than Python 3.8, so that an older interpreter still reports
its own version as a FAIL line instead of stopping with a syntax error.
"""

from __future__ import annotations

import argparse
import configparser
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Mapping, Optional, Sequence, Tuple

REQUIRED_REGION = "eu-west-2"
MIN_PYTHON = (3, 12, 0)

# Seconds to wait for a version command, and for the sign-in check, which
# makes a network call to AWS.
VERSION_TIMEOUT = 60
IDENTITY_TIMEOUT = 90

SETUP_GUIDE = "laptop-setup.md"

Version = Tuple[int, int, int]


@dataclass(frozen=True)
class CommandResult:
    """The exit status and the captured output of one command."""

    returncode: int
    stdout: str
    stderr: str


@dataclass(frozen=True)
class Check:
    """The result of one check, as the script prints it."""

    name: str
    passed: bool
    message: str
    # A warning passes but prints as WARN, for a setting the course allows but
    # does not prefer.
    warning: bool = False


@dataclass(frozen=True)
class ToolSpec:
    """A command-line tool that the course needs, and its minimum version."""

    command: str
    label: str
    minimum: Version
    install_hint: str


# A runner takes the full argument list and a timeout in seconds. Tests replace
# it with a stub so that they need none of the tools installed.
Runner = Callable[[Sequence[str], int], CommandResult]
# A finder returns the full path of a command on the PATH, or None.
Finder = Callable[[str], Optional[str]]


TOOLS: Tuple[ToolSpec, ...] = (
    ToolSpec(
        command="uv",
        label="uv",
        minimum=(0, 9, 0),
        install_hint=f"Install or update uv with step 1 of {SETUP_GUIDE}.",
    ),
    ToolSpec(
        command="aws",
        label="AWS CLI",
        minimum=(2, 27, 42),
        install_hint=(
            f"Install or update AWS CLI version 2 with step 3 of {SETUP_GUIDE}. "
            "The labs use `aws bedrock get-foundation-model-availability`, which AWS CLI "
            "versions before 2.27.42 lack."
        ),
    ),
    ToolSpec(
        command="node",
        label="Node.js",
        minimum=(20, 12, 0),
        install_hint=f"Install Node.js 24 with step 4 of {SETUP_GUIDE}.",
    ),
    ToolSpec(
        command="npm",
        label="npm",
        minimum=(10, 0, 0),
        install_hint=f"npm comes with Node.js. Install Node.js 24 with step 4 of {SETUP_GUIDE}.",
    ),
    ToolSpec(
        command="agentcore",
        label="AgentCore CLI",
        minimum=(1, 0, 0),
        install_hint=(
            "Install it with `npm install -g @aws/agentcore` "
            f"(step 5 of {SETUP_GUIDE}). Versions before 1.0.0 are the unsupported "
            "Python starter toolkit or an early release. If the starter toolkit is "
            "installed, remove it with `pip uninstall bedrock-agentcore-starter-toolkit`, "
            "because both tools provide an `agentcore` command."
        ),
    ),
)

VERSION_PATTERN = re.compile(r"(\d+)\.(\d+)(?:\.(\d+))?")

# Patterns for values that must never reach the terminal.
ARN_PATTERN = re.compile(r"arn:aws[A-Za-z-]*:[^\s'\"]*")
ACCESS_KEY_PATTERN = re.compile(r"(?<![A-Z0-9])(?:AKIA|ASIA|AIDA|AROA|ANPA|AGPA)[A-Z0-9]{12,}")
ACCOUNT_PATTERN = re.compile(r"(?<!\d)\d{12}(?!\d)")
SECRET_PATTERN = re.compile(r"(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])")

# A long-term IAM user access key starts with AKIA. Temporary keys from a
# sign-in session start with ASIA and are not a stored key.
LONG_TERM_KEY_ID = re.compile(r"^AKIA[A-Z0-9]{16}$")

MAX_DETAIL_LENGTH = 200


def format_version(version: Sequence[int]) -> str:
    """Return a version tuple as dotted text, such as 3.13.5."""
    return ".".join(str(part) for part in version)


def parse_version(text: str) -> Optional[Version]:
    """Return the first dotted version number in text, or None.

    Tools print their versions in different shapes: `uv 0.13.6 (...)`,
    `aws-cli/2.39.3 Python/3.13.7 ...`, `v24.22.2` and `1.0.1`. The first
    number with at least one dot is the tool's own version in each of them.
    """
    match = VERSION_PATTERN.search(text or "")
    if match is None:
        return None
    return (int(match.group(1)), int(match.group(2)), int(match.group(3) or 0))


def redact(text: str) -> str:
    """Hide ARNs, access key IDs, secrets and 12-digit account identifiers."""
    text = ARN_PATTERN.sub("<ARN hidden>", text)
    text = ACCESS_KEY_PATTERN.sub("<key hidden>", text)
    text = ACCOUNT_PATTERN.sub("<account hidden>", text)
    return SECRET_PATTERN.sub("<secret hidden>", text)


def first_line(text: str) -> str:
    """Return the first non-empty line of text, shortened for one PASS or FAIL line."""
    for line in (text or "").splitlines():
        line = line.strip()
        if line:
            if len(line) > MAX_DETAIL_LENGTH:
                return line[: MAX_DETAIL_LENGTH - 3] + "..."
            return line
    return "no error message was printed."


def run_command(args: Sequence[str], timeout: int) -> CommandResult:
    """Run one command without a shell and capture its output.

    Standard input is closed, so a tool that asks a question on first use
    fails quickly instead of waiting. AWS_PAGER is set to an empty string so
    that the AWS CLI never opens a pager.
    """
    environment = dict(os.environ)
    environment["AWS_PAGER"] = ""
    try:
        completed = subprocess.run(
            list(args),
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            env=environment,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return CommandResult(124, "", f"The command did not finish within {timeout} seconds.")
    except OSError as error:
        return CommandResult(127, "", f"The command could not start: {error}")
    return CommandResult(completed.returncode, completed.stdout or "", completed.stderr or "")


def check_python(version_info: Sequence[int]) -> Check:
    """Check that the interpreter running this script is Python 3.12 or later."""
    found = tuple(int(part) for part in tuple(version_info)[:3])
    if found >= MIN_PYTHON:
        return Check("Python", True, f"Python {format_version(found)} is running this check.")
    return Check(
        "Python",
        False,
        f"Python {format_version(found)} is running this check, and the course needs "
        f"{format_version(MIN_PYTHON[:2])} or later. Install Python 3.13 with step 2 of "
        f"{SETUP_GUIDE}, then run the check with `uv run check_laptop.py`.",
    )


def check_tool(spec: ToolSpec, finder: Finder, runner: Runner) -> Check:
    """Check that a tool is on the PATH and reports a version at or above the minimum."""
    path = finder(spec.command)
    if path is None:
        return Check(spec.label, False, f"`{spec.command}` was not found on your PATH. {spec.install_hint}")
    result = runner([path, "--version"], VERSION_TIMEOUT)
    version = None
    if result.returncode == 0:
        # Most tools print their version on standard output. AWS CLI version 1
        # prints it on standard error.
        version = parse_version(result.stdout) or parse_version(result.stderr)
    if version is None:
        return Check(
            spec.label,
            False,
            f"`{spec.command} --version` did not report a version. {spec.install_hint}",
        )
    if version < spec.minimum:
        return Check(
            spec.label,
            False,
            f"{spec.label} {format_version(version)} is installed, and the course needs "
            f"{format_version(spec.minimum)} or later. {spec.install_hint}",
        )
    return Check(spec.label, True, f"{spec.label} {format_version(version)} is installed.")


def check_region(environ: Mapping[str, str]) -> Check:
    """Check that AWS_DEFAULT_REGION is eu-west-2 and that AWS_REGION does not override it."""
    default_region = environ.get("AWS_DEFAULT_REGION", "").strip()
    override = environ.get("AWS_REGION", "").strip()
    fix = f"Set it with step 6 of {SETUP_GUIDE}, open a new terminal, and run the check again."
    if not default_region:
        return Check("AWS Region", False, f"AWS_DEFAULT_REGION is not set. {fix}")
    if default_region != REQUIRED_REGION:
        shown = redact(default_region[:40])
        return Check(
            "AWS Region",
            False,
            f"AWS_DEFAULT_REGION is {shown}, and the course uses {REQUIRED_REGION}. {fix}",
        )
    if override and override != REQUIRED_REGION:
        shown = redact(override[:40])
        return Check(
            "AWS Region",
            False,
            f"AWS_REGION is {shown}, and it overrides AWS_DEFAULT_REGION. "
            f"Remove AWS_REGION, or set it to {REQUIRED_REGION}.",
        )
    return Check("AWS Region", True, f"AWS_DEFAULT_REGION is {REQUIRED_REGION}.")


def _read_ini(path: Path) -> Optional[configparser.RawConfigParser]:
    """Read an AWS CLI configuration file. Return None if the file does not exist."""
    if not path.is_file():
        return None
    parser = configparser.RawConfigParser(strict=False)
    parser.read(path, encoding="utf-8")
    return parser


def check_access_key(environ: Mapping[str, str], home: Path) -> Check:
    """Warn when the course profile uses a long-term access key.

    The course prefers IAM Identity Center, which keeps only short-term
    credentials in the AWS CLI's own cache. A learner whose account has no
    IAM Identity Center uses an access key for their own IAM user, stored by
    `aws configure` in the AWS CLI's credentials file and never in a file in
    the course folder. A long-term key is therefore a WARN line, not a FAIL
    line. The check looks only at the profile that the CLI uses, which is
    `default` unless AWS_PROFILE names another one. Other profiles on the
    laptop are left alone.
    """
    profile = environ.get("AWS_PROFILE", "").strip() or "default"
    credentials_path = Path(environ.get("AWS_SHARED_CREDENTIALS_FILE") or home / ".aws" / "credentials")
    config_path = Path(environ.get("AWS_CONFIG_FILE") or home / ".aws" / "config")
    config_section = "default" if profile == "default" else f"profile {profile}"
    try:
        credentials = _read_ini(credentials_path)
        config = _read_ini(config_path)
    except (configparser.Error, OSError, UnicodeDecodeError):
        return Check(
            "Access key",
            False,
            "Your AWS CLI configuration files could not be read. Check them with "
            "`aws configure list`, or set up your profile again with step 7 of "
            f"{SETUP_GUIDE}.",
        )
    in_profile = (credentials is not None and credentials.has_option(profile, "aws_secret_access_key")) or (
        config is not None and config.has_option(config_section, "aws_secret_access_key")
    )
    in_environment = bool(LONG_TERM_KEY_ID.match(environ.get("AWS_ACCESS_KEY_ID", "").strip()))
    if in_environment:
        return Check(
            "Access key",
            True,
            "A long-term access key is set in the AWS_ACCESS_KEY_ID environment variable. "
            f"Store the key in the `{profile}` profile with `aws configure --profile {profile}` "
            f"instead, as step 7 of {SETUP_GUIDE} describes, and remove the environment variables.",
            warning=True,
        )
    if in_profile:
        return Check(
            "Access key",
            True,
            f"The `{profile}` profile uses a long-term access key. The course allows this only "
            "when your AWS account has no IAM Identity Center. Keep the key in the AWS CLI's own "
            "files and never copy it into a file in the course folder.",
            warning=True,
        )
    return Check(
        "Access key",
        True,
        f"The `{profile}` profile uses no long-term access key.",
    )


def check_caller_identity(finder: Finder, runner: Runner) -> Check:
    """Check that `aws sts get-caller-identity` succeeds, without printing what it returns."""
    path = finder("aws")
    if path is None:
        return Check(
            "AWS sign-in",
            False,
            f"The sign-in check needs the AWS CLI, which was not found. Install it with step 3 of {SETUP_GUIDE}.",
        )
    result = runner([path, "sts", "get-caller-identity", "--output", "json"], IDENTITY_TIMEOUT)
    if result.returncode == 0:
        try:
            identity = json.loads(result.stdout)
        except ValueError:
            identity = None
        if isinstance(identity, dict) and identity.get("Account") and identity.get("Arn"):
            return Check(
                "AWS sign-in",
                True,
                "`aws sts get-caller-identity` succeeded. The account and identity are not shown.",
            )
        return Check(
            "AWS sign-in",
            False,
            "`aws sts get-caller-identity` returned a response without an account and an "
            f"identity. Sign in again with step 7 of {SETUP_GUIDE}.",
        )
    detail = first_line(redact(result.stderr or result.stdout))
    if not detail.endswith((".", "!", "?")):
        detail += "."
    return Check(
        "AWS sign-in",
        False,
        f"`aws sts get-caller-identity` failed: {detail} Sign in with `aws sso login`, or "
        f"check the access key in your profile, as step 7 of {SETUP_GUIDE} describes. "
        "Then run the check again.",
    )


def run_checks(
    environ: Mapping[str, str],
    home: Path,
    finder: Finder,
    runner: Runner,
    version_info: Sequence[int],
) -> List[Check]:
    """Run every check in the order the setup guide installs things."""
    checks = [check_python(version_info)]
    checks.extend(check_tool(spec, finder, runner) for spec in TOOLS)
    checks.append(check_region(environ))
    checks.append(check_access_key(environ, home))
    checks.append(check_caller_identity(finder, runner))
    return checks


def format_check(check: Check) -> str:
    """Return one output line. The output uses ASCII only, for any Windows console."""
    if not check.passed:
        status = "FAIL"
    elif check.warning:
        status = "WARN"
    else:
        status = "PASS"
    line = f"[{status}] {check.name}: {check.message}"
    return line.encode("ascii", "replace").decode("ascii")


def build_parser() -> argparse.ArgumentParser:
    """Return the command-line parser. The script takes no arguments."""
    return argparse.ArgumentParser(
        prog="check_laptop.py",
        description=(
            "Check that this laptop is ready for the AWS FDE programme: Python 3.12 or "
            "later, uv, AWS CLI version 2.27.42 or later, Node.js 20.12 or later, npm, the "
            "AgentCore CLI 1.0 or later, AWS_DEFAULT_REGION set to eu-west-2, and a working "
            "AWS CLI sign-in. It warns when the AWS CLI profile uses a long-term access key. "
            "The check changes nothing and never prints an account identifier, a key or an ARN."
        ),
    )


def main(
    argv: Optional[Sequence[str]] = None,
    *,
    environ: Optional[Mapping[str, str]] = None,
    home: Optional[Path] = None,
    finder: Optional[Finder] = None,
    runner: Optional[Runner] = None,
    version_info: Optional[Sequence[int]] = None,
) -> int:
    """Run the checks, print one line for each, and return the exit status."""
    build_parser().parse_args(argv)
    checks = run_checks(
        environ=os.environ if environ is None else environ,
        home=Path.home() if home is None else home,
        finder=shutil.which if finder is None else finder,
        runner=run_command if runner is None else runner,
        version_info=sys.version_info if version_info is None else version_info,
    )
    print("Checking this laptop for the AWS FDE programme. The check changes nothing.")
    for check in checks:
        print(format_check(check))
    failed = [check for check in checks if not check.passed]
    warned = [check for check in checks if check.passed and check.warning]
    if failed:
        # Until a learner's AWS access is ready, which can be as late as the start of Week 2, the sign-in check
        # is the one check that can't pass yet. Say so, rather than telling the learner to fix it.
        if all(check.name == "AWS sign-in" for check in failed):
            print(
                f"{len(failed)} of {len(checks)} checks failed, and it is the AWS sign-in check. If your AWS access "
                "isn't ready yet, that is the expected result, and the rest of this laptop is ready. "
                f"When your access is ready, complete step 7 of {SETUP_GUIDE} and run the check again."
            )
            return 1
        print(
            f"{len(failed)} of {len(checks)} checks failed. Fix each FAIL line with the step "
            f"it names in {SETUP_GUIDE}, then run the check again."
        )
        return 1
    if warned:
        print(
            f"All {len(checks)} checks passed, with {len(warned)} warning. Read the WARN line. "
            "You can show this output to the instructor."
        )
        return 0
    print(f"All {len(checks)} checks passed. You can show this output to the instructor.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
