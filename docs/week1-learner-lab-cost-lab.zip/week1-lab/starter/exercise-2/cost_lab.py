"""Cost lab: price model calls and forecast Kestrel's monthly bill from data/pricing.json.

Save this file in starter/exercise-2/ and run it from that folder with:

    uv run python cost_lab.py

It makes no AWS calls and needs no credentials.
"""

from __future__ import annotations

from support_assistant import ledger

LONG_CONTEXT_THRESHOLD = 100_000  # tokens of input, from the Claude Haiku 5.5 row in pricing.json

COURSE = "eu.anthropic.claude-haiku-4-5-20251001-v1:0"
SONNET_46 = "eu.anthropic.claude-sonnet-4-6"
HAIKU_55 = "eu.anthropic.claude-haiku-5-5"
SONNET_55 = "eu.anthropic.claude-sonnet-5-5"


# ----------------------------------------------------------------------------- Task 2

def call_cost(row: dict, usage: dict, *, cache_ttl: str = "5m", batch: bool = False) -> tuple[float | None, str]:
    """Return the cost of one call in US dollars and how it was decided.

    `row` is one model row from pricing.json and `usage` a Converse usage block.
    `cache_ttl` is "5m" or "1h", the time to live that the request asked for.
    `batch` is True for a batch inference job.
    """
    # TODO Task 2: price input and output tokens with the row's "input" and "output" rates.
    # TODO Task 3: add cache reads and writes, the 1-hour write rate, the long-context
    #              rates and batch prices, as the lab page describes.
    raise NotImplementedError("complete call_cost() (Task 2)")


# ----------------------------------------------------------------------------- Task 4

def monthly_forecast(row: dict, prices: ledger.Prices, *, questions_per_day: int, days: int,
                     calls_per_question: int, retry_rate: float, usage_per_call: dict,
                     retrieves_per_question: int) -> dict:
    """Return the forecast monthly cost of the assistant for one model."""
    # TODO Task 4: count the questions and the model-call attempts, including retries,
    # price one call with call_cost(), add the Retrieve calls, and return the dict
    # that the lab page describes.
    raise NotImplementedError("complete monthly_forecast() (Task 4)")


# ----------------------------------------------------------------------------- report
# You don't need to change anything below this line.

def task_1(prices: ledger.Prices) -> None:
    print("Task 1: the price register")
    print(f"  {'model':<20}{'input':>8}{'output':>8}{'out/in':>8}{'read/in':>9}{'batch/in':>9}  lifecycle")
    for row in prices.per_million.values():
        batch = f"{row['batch_input'] / row['input']:.0%}" if row["batch_input"] else "n/a"
        print(f"  {row['model_name']:<20}{row['input']:>8.3f}{row['output']:>8.3f}"
              f"{row['output'] / row['input']:>8.1f}{row['cache_read'] / row['input']:>9.0%}{batch:>9}  {row['lifecycle']}")


def task_2(prices: ledger.Prices) -> None:
    print("Task 2: one call, 25 input and 31 output tokens")
    usage = {"inputTokens": 25, "outputTokens": 31}
    for model_id, row in prices.per_million.items():
        mine, _ = call_cost(row, usage)
        theirs, _ = ledger.model_cost(prices, model_id, usage)
        print(f"  {row['model_name']:<20}{mine:.8f}  ledger {theirs:.8f}  {'same' if mine == theirs else 'DIFFERENT'}")


def task_3(prices: ledger.Prices) -> None:
    row = prices.model(COURSE)
    plain = {"inputTokens": 5_300, "outputTokens": 250}
    write = {"inputTokens": 300, "outputTokens": 250, "cacheWriteInputTokens": 5_000}
    read = {"inputTokens": 300, "outputTokens": 250, "cacheReadInputTokens": 5_000}
    print("Task 3a: 20 calls in five minutes with a 5,000-token stable prefix, Claude Haiku 4.5")
    no_cache = 20 * call_cost(row, plain)[0]
    cached = call_cost(row, write)[0] + 19 * call_cost(row, read)[0]
    print(f"  no cache {no_cache:.6f}  cached {cached:.6f}  saving {1 - cached / no_cache:.1%}")
    print(f"  one call that writes the cache {call_cost(row, write)[0]:.6f}, "
          f"the same call without caching {call_cost(row, plain)[0]:.6f}")
    print("Task 3b: where your function and model_cost() differ")
    print(f"  1-hour cache write     yours {call_cost(row, write, cache_ttl='1h')[0]:.6f}  "
          f"ledger {ledger.model_cost(prices, COURSE, write)[0]:.6f}")
    big = {"inputTokens": 120_000, "outputTokens": 1_000}
    cost, status = call_cost(prices.model(HAIKU_55), big)
    print(f"  Haiku 5.5, 120k input  yours {cost:.6f}  ledger {ledger.model_cost(prices, HAIKU_55, big)[0]:.6f}  ({status})")
    print("Task 3c: the same 5,300-token call as a batch job")
    for model_id in (COURSE, SONNET_55):
        print(f"  {prices.model(model_id)['model_name']:<20}{call_cost(prices.model(model_id), plain, batch=True)}")


ASSUMPTIONS = dict(questions_per_day=1_500, days=30, calls_per_question=3, retry_rate=0.05,
                   usage_per_call={"inputTokens": 2_400, "outputTokens": 300}, retrieves_per_question=1)


def task_4(prices: ledger.Prices) -> None:
    print("Task 4: monthly forecast")
    print(f"  {'model':<20}{'attempts':>9}{'model $':>10}{'retrieve $':>12}{'total $':>10}{'per question $':>16}")
    for model_id in (COURSE, SONNET_46, HAIKU_55, SONNET_55):
        f = monthly_forecast(prices.model(model_id), prices, **ASSUMPTIONS)
        print(f"  {prices.model(model_id)['model_name']:<20}{f['attempts']:>9,}{f['model_usd']:>10,.2f}"
              f"{f['retrieve_usd']:>12,.2f}{f['total_usd']:>10,.2f}{f['per_question_usd']:>16.6f}")


def main() -> None:
    prices = ledger.load_prices()
    print(f"Prices read on {prices.read_on} for {len(prices.per_million)} models")
    for task in (task_1, task_2, task_3, task_4):
        print()
        try:
            task(prices)
        except NotImplementedError as error:
            print(f"  Not done yet: {error}")


if __name__ == "__main__":
    main()
